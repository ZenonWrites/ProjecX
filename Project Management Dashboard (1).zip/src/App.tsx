import { ProjectsPage } from "./components/ProjectsPage";

export default function App() {
  return <ProjectsPage />;
}
